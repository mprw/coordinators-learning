//
//  RedScreenViewController.swift
//  AppCoordinatorsLearning
//
//  Created by Martyn on 9/27/17.
//  Copyright © 2017 Martyn. All rights reserved.
//

import UIKit

class RedScreenViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
