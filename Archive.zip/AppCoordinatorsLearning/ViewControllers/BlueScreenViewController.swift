//
//  BlueScreenViewController.swift
//  AppCoordinatorsLearning
//
//  Created by Martyn on 9/27/17.
//  Copyright © 2017 Martyn. All rights reserved.
//

import UIKit

class BlueScreenViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
